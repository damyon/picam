App to control a camera via USB over the web.
